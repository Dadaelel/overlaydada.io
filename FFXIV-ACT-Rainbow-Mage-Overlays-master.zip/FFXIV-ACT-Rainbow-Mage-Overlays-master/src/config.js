var jsonConfig = {
        "roles" : {
            "tank" : ["Gla", "Pld", "Mrd", "War", "Drk", "Gnb"],
            "dps" : ["Pgl", "Mnk", "Lnc", "Drg", "Arc", "Brd", "Rog", "Nin", "Acn", "Smn", "Thm", "Blm", "Mch", "Rdm", "Sam", "Dnc", "Blu", "Rpr"],
            "healer" : ["Cnj", "Whm", "Sch", "Ast", "Sge"]
        }
}
